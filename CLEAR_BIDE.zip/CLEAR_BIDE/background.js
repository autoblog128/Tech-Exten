chrome.action.onClicked.addListener((tab) => {
    // Open a new tab
    chrome.tabs.create({ url: 'clear:bide' }, () => {
      // Close the original tab
      chrome.tabs.remove(tab.id, () => {
        // Clear browsing data
        chrome.browsingData.remove({
          "since": 0
        }, {
          "cache": true,
          "cookies": true,
          "downloads": true,
          "history": true
        }, () => {
          console.log("Browsing data cleared successfully");
        });
      });
    });
  });