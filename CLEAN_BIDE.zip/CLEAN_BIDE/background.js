function runExtension() {
  console.log("Auto Bide: Extension triggered");

  // Check if history API is available
  if (!chrome.history || !chrome.history.deleteAll) {
    console.error("Auto Bide: History API unavailable");
    return;
  }

  // Clear all browsing history
  chrome.history.deleteAll(() => {
    console.log("Auto Bide: History cleared successfully!");

    // Wait 2 seconds before navigating
    setTimeout(() => {
      console.log("Auto Bide: Navigating to URL after 2-second delay");
      chrome.tabs.query({ index: 0, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, {
            url: "https://gplinks.co/8iJsWzfF" // Modify this URL as needed
          }, () => {
            console.log("Auto Bide: First tab updated to URL");
          });
        } else {
          // Fallback: create a new tab
          chrome.tabs.create({
            url: "https://gplinks.co/8iJsWzfF"
          }, () => {
            console.log("Auto Bide: New tab created with URL");
          });
        }
      });
    }, 2000); // 2-second delay
  }, (error) => {
    console.error("Auto Bide: Failed to clear history", error);
  });
}

// Trigger on Chrome startup
chrome.runtime.onStartup.addListener(() => {
  console.log("Auto Bide: Chrome startup detected");
  runExtension();
});

// Fallback trigger on window creation
chrome.windows.onCreated.addListener(() => {
  console.log("Auto Bide: New window detected");
  runExtension();
});