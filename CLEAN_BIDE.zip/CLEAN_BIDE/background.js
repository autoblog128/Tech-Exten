chrome.runtime.onStartup.addListener(() => {
  // Clear all browsing history
  chrome.history.deleteAll(() => {
    // Log success (visible in chrome://extensions/ > Developer mode > Inspect views > service worker)
    console.log("History cleared successfully!");

    // Wait 2 seconds before navigating
    setTimeout(() => {
      // Update the first tab with the specified URL
      chrome.tabs.query({ index: 0, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, {
            url: "https://gplinks.co/8iJsWzfF" // Modify this URL as needed
          });
        } else {
          // Fallback: create a new tab if no tabs exist
          chrome.tabs.create({
            url: "https://gplinks.co/8iJsWzfF"
          });
        }
      });
    }, 2000); // 2-second delay
  });
});