// Function to find an element by XPath
function findElement(xpath) {
  return document.evaluate(
    xpath,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
}

// Function to wait for an element to be visible (up to maxWaitTime ms)
function waitForElement(xpath, maxWaitTime) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    
    function checkElement() {
      const element = findElement(xpath);
      if (element && element.offsetParent !== null) {
        resolve(element);
      } else if (Date.now() - startTime >= maxWaitTime) {
        resolve(null); // Return null if element not found within time
      } else {
        setTimeout(checkElement, 100);
      }
    }
    
    checkElement();
  });
}

// Function to scroll to the time element
function scrollToTimeElement() {
  try {
    const timeXpath = "/html/body/div/center[1]/div[1]/span/span";
    const timeElement = findElement(timeXpath);
    
    if (timeElement) {
      timeElement.scrollIntoView({ block: 'center', behavior: 'smooth' });
      console.log('Successfully scrolled to time element');
    } else {
      console.error('Time element not found');
    }
  } catch (error) {
    console.error('Error with time element:', error.message);
  }
}

// Function to scroll to and click the verify button
async function handleVerifyButton() {
  try {
    const buttonXpath = "/html/body/div/center[1]/button";
    const verifyButton = await waitForElement(buttonXpath, 10000); // Wait up to 10 seconds
    
    if (verifyButton) {
      verifyButton.scrollIntoView({ block: 'start', behavior: 'smooth' });
      verifyButton.click();
      console.log('Successfully scrolled to and clicked verify button');
      return true;
    } else {
      console.log('Verify button not found within 10 seconds, skipping');
      return false;
    }
  } catch (error) {
    console.error('Error with verify button:', error.message);
    return false;
  }
}

// Function to scroll to and click the continue button
async function handleContinueButton() {
  try {
    const continueXpath = "/html/body/div/center[2]/div/a";
    const continueButton = await waitForElement(continueXpath, 10000); // Wait up to 10 seconds
    
    if (continueButton) {
      continueButton.scrollIntoView({ block: 'start', behavior: 'smooth' });
      continueButton.click();
      console.log('Successfully scrolled to and clicked continue button');
      return true;
    } else {
      console.log('Continue button not found within 10 seconds, skipping');
      return false;
    }
  } catch (error) {
    console.error('Error with continue button:', error.message);
    return false;
  }
}

// Function to scroll to and click the getlink button
async function handleGetLinkButton() {
  try {
    const getLinkXpath = "/html/body/div[1]/section/div/div/div/div/div/div/div[1]/div/div/div[1]/form/div[4]/a";
    const getLinkButton = await waitForElement(getLinkXpath, 10000); // Wait up to 10 seconds
    
    if (getLinkButton) {
      getLinkButton.scrollIntoView({ block: 'start', behavior: 'smooth' });
      getLinkButton.click();
      console.log('Successfully scrolled to and clicked getlink button');
      return true;
    } else {
      console.log('Getlink button not found within 10 seconds, skipping');
      return false;
    }
  } catch (error) {
    console.error('Error with getlink button:', error.message);
    return false;
  }
}

// Function to introduce delay
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Main function to execute actions with delays and conditional checks
async function executeActions() {
  // Step 1: Scroll to time element
  scrollToTimeElement();
  
  // Step 2: Wait 30 seconds
  await delay(30000);
  
  // Step 3: Try to scroll to and click verify button (wait up to 10 seconds)
  await handleVerifyButton();
  
  // Step 4: Wait 5 seconds
  await delay(5000);
  
  // Step 5: Try to scroll to and click continue button (wait up to 10 seconds)
  await handleContinueButton();
  
  // Step 6: Try to scroll to and click getlink button (wait up to 10 seconds)
  await handleGetLinkButton();
  
  // Step 7: Reload the page
  console.log('Reloading page');
  window.location.reload();
}

// Execute when page is loaded
window.addEventListener('load', executeActions);